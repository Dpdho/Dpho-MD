###📝 HARAP DI BACA

script ini sebenarnya sudah tidak saya update kali karena mau fokus ke satu script aja, cuman karena banyak keluhan dari kalian jadi saya lanjutkan.

###📌 CREDIT SC

buat yang mau recode sc ini silahkan recode sekreatif kalian, cuman mohon untuk jangan di hapus credits dari pembuat scriptnya karena pembuat script nya sudah capek² buat dan benerin sc bot wa untuk di pakai tapi malah di hapus atau ganti, gw pengen credits nya di tambahin bukan di HAPUS!!!

###👤 KONTRIBUSI

Jika kamu menggunakan sc ini berarti kamu sudah kontribusi dalam pembuatan sc ini

• LT SYAII ( PEMBUAT )
• WHISKEYSOCKETS ( PENYEDIA BAILEYS )
• MIFTAH ( PENYEDIA API ITZPIRE 🔥 )
• SIPUTZ ( PENYEDIA API GEMINI 🔥 )
• DANZ CODING ( SEPUH 🗿 )

silahkan masukkan nama kalian agar termasuk dalam bagian dari kontribusi sc ini

### 🙏🏼 TERIMAKASIH SUDAH PAKAI SCRIPT INI 